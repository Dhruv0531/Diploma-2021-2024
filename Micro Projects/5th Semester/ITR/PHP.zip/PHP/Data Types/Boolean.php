<?php
	$x = true;
	$y = false;
	
?>