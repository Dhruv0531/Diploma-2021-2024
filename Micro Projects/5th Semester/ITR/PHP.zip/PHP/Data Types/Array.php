<!DOCTYPE html>
<html>
	<body>

		<?php  
		$cars = array("Volvo","BMW",2);
		echo "<pre>";
		var_dump($cars);
		?>  

	</body>
</html>
