<!DOCTYPE html>
<html>
	<body>

		<?php
		echo strrev("Hello world!");
		?> 
	 
	</body>
</html>
