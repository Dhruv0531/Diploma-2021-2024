<!DOCTYPE html>
<html>
	<body>

		<?php
		echo str_word_count("Hello world! hjhjn fdgdf fsdgsdfg gfdg");
		?> 
	 
	</body>
</html>
