<!DOCTYPE html>
<html>
	<body>

		<?php
		define("GREETING", "Welcome to php!");

		function myTest() {
		  echo GREETING;
		}
		 
		myTest();
		?> 

	</body>
</html>

