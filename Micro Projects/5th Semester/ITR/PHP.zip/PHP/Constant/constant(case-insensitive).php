<!DOCTYPE html>
<html>
	<body>

		<?php
		// case-insensitive constant name
		define("GREETING", "Welcome to PHP!", true);
		echo Greeting;
		?> 

	</body>
</html>
