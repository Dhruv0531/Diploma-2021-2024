<!DOCTYPE html>
<html>
	<body>

		<?php
		// case-sensitive constant name
		define("GREETING", "Welcome to InnovationsHub!");
		ECHO GREETING;
		?> 

	</body>
</html>
