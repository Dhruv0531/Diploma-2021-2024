<!DOCTYPE html>
<html>
	<body>

		<?php
		// Invalid calculation will return a NaN value
		$x = acos(8);
		var_dump($x);
		?>  

	</body>
</html>
