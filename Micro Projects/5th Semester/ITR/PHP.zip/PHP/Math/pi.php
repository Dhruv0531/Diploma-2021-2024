<!DOCTYPE html>
<html>
	<body>

		<?php
		echo(pi());
		?>

	</body>
</html>
