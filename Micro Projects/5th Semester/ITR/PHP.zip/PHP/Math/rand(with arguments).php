<!DOCTYPE html>
<html>
	<body>

		<?php
		echo(rand(1000, 10000));
		?>

	</body>
</html>
