<!DOCTYPE html>
<html>
	<body>

		<?php
		echo(round(0.60) . "<br>");
		echo(round(0.50) . "<br>");
		echo(round(0.49) . "<br>");
		echo(round(-4.40) . "<br>");
		echo(round(-4.60));
		?>



	</body>
</html>
