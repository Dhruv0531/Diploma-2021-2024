<!DOCTYPE html>
<html>
	<body>

		<?php
		echo(min(0, 150, 30, 20, -8, -200) . "<br>");
		echo(max(0, 150, 30, 20, -8, -200));
		?>

	</body>
</html>
