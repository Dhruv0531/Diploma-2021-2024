<!DOCTYPE html>
<html>
	<body>

		<?php
		$txt1 = "Hello";
		$txt2 = " world!";
		echo $txt1 . $txt2;
		?>  

	</body>
</html>
