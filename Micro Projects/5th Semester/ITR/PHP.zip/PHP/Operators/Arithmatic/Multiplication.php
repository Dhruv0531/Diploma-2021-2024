<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 10;  
		$y = 6;

		echo $x * $y;
		?>  

	</body>
</html>
