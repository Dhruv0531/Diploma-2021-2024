<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 10;  
		$y = 3;

		echo $x ** $y;
		?>  

	</body>
</html>
