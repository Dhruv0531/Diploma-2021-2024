<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 10;  
		echo --$x;
		?>  

	</body>
</html>
