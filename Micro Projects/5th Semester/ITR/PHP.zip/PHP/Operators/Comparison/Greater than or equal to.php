<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 50;
		$y = 50;

		var_dump($x >= $y); // returns true because $x is greater than or equal to $y
		?>  

	</body>
</html>
