<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 10;
		$x /= 5;

		echo $x;
		?>  

	</body>
</html>
