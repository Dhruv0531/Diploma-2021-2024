<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 15;
		$x %= 4;

		echo $x;
		?>  

	</body>
</html>
