<!DOCTYPE html>
<html>
	<body>

		<?php
		$x = 5;
		$x *= 6;

		echo $x;
		?>  

	</body>
</html>