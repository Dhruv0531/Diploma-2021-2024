<!DOCTYPE html>
<html>
	<body>

	<?php
	print "<h2>PHP is Fun!</h2>";
	print "Hello world!<br>";
	print "I'm about to learn PHP!";
	?> 

	</body>
</html>
