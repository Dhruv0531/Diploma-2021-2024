<!DOCTYPE html>
<html>
<body>
<p><h2>PHP $_GET</h2><br>
PHP $_GET is a PHP super global variable which is used to collect form data after submitting an HTML form with method="get".<br>

$_GET can also collect data sent in the URL.</p>

<a href="test_get.php?subject=PHP&web=W3schools.com">Test $GET</a>

</body>
</html>