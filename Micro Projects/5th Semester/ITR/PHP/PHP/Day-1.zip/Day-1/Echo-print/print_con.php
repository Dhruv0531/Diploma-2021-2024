<!DOCTYPE html>
<html>
	<body>

	<?php
	$txt1 = "PHP";
	$txt2 = "Easy to learn";
	$x = 5;
	$y = 4;

	print "<h2>" . $txt1 . "</h2>";
	print "PHP is " . $txt2 . "<br>";
	print $x + $y;
	?>

	</body>
</html>