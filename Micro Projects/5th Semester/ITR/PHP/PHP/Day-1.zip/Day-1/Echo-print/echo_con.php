<?php
	$txt1 = "PHP";
	$txt2 = "Easy to learn";
	$x = 5;
	$y = 4;

	echo "<h2>" .$txt1 . "</h2>";
	echo "PHP is  " . $txt2 . "<br>";
	echo $x + $y;
?>